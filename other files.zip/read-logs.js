const fs = require('fs');
const readline = require('readline');

async function run() {
  const fileStream = fs.createReadStream('C:\\Users\\Krish\\.gemini\\antigravity-ide\\brain\\4d6edd1c-4b91-45e7-a67f-1d8370492429\\.system_generated\\logs\\transcript_full.jsonl');
  const rl = readline.createInterface({
    input: fileStream,
    crlfDelay: Infinity
  });

  for await (const line of rl) {
    const parsed = JSON.parse(line);
    const lineStr = line.toLowerCase();
    if (lineStr.includes('password') || lineStr.includes('migration') || lineStr.includes('connect') || lineStr.includes('sql')) {
      console.log(`Step ${parsed.step_index}: type=${parsed.type}`);
      const content = JSON.stringify(parsed.content || parsed.tool_calls || parsed.output || '').substring(0, 300);
      console.log(`  Content: ${content}`);
    }
  }
}

run();


