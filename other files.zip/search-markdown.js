const fs = require('fs');

const content = fs.readFileSync('user_request_phase4.md', 'utf8');
const lines = content.split('\n');

for (let i = 0; i < lines.length; i++) {
  const line = lines[i];
  if (line.startsWith('## ') || line.startsWith('### ')) {
    console.log(`Line ${i + 1}: ${line}`);
  }
}
