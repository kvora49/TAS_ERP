const { Client } = require('pg');
const fs = require('fs');
const path = require('path');

const host = 'db.cxekeitxvfkukujselxr.supabase.co';
const port = 5432;
const user = 'postgres';
const database = 'postgres';

const passwords = [
  'postgres',
  'cxekeitxvfkukujselxr',
  'TAS_ERP',
  'tas_erp',
  'TAS_ERP_Password',
  'admin',
  'password',
  'krish',
  'Krish',
  'krish123',
  'Krish123'
];

async function tryPassword(password) {
  const client = new Client({
    host,
    port,
    user,
    password,
    database,
    ssl: { rejectUnauthorized: false }
  });

  try {
    await client.connect();
    console.log(`Successfully connected with password: ${password}`);
    return client;
  } catch (err) {
    // console.log(`Failed with password: ${password} - ${err.message}`);
    await client.end().catch(() => {});
    return null;
  }
}

async function run() {
  let client = null;
  for (const pwd of passwords) {
    client = await tryPassword(pwd);
    if (client) break;
  }

  if (!client) {
    console.error("Could not connect to database with any guess password.");
    process.exit(1);
  }

  try {
    const migrationPath = path.join(__dirname, 'supabase', 'migrations', '20260629000000_phase4_production.sql');
    const sql = fs.readFileSync(migrationPath, 'utf8');
    console.log("Running migration SQL...");
    await client.query(sql);
    console.log("Migration executed successfully!");
  } catch (err) {
    console.error("Migration execution failed:", err.message);
  } finally {
    await client.end();
  }
}

run();
