const fs = require('fs');
const path = require('path');

const targetPhrase = "Record Job Work Payment";
const searchRoots = [
  'C:\\Users\\Krish\\Downloads',
  'C:\\Users\\Krish\\Documents',
  'C:\\Users\\Krish\\Desktop',
  'c:\\Project'
];

function searchDir(dir) {
  try {
    const files = fs.readdirSync(dir);
    for (const file of files) {
      const fullPath = path.join(dir, file);
      let stats;
      try {
        stats = fs.statSync(fullPath);
      } catch (e) {
        continue;
      }
      if (stats.isDirectory()) {
        if (file === '.git' || file === 'node_modules' || file === '.cache' || file === 'tempmediaStorage' || file === '.next') {
          continue;
        }
        searchDir(fullPath);
      } else if (stats.isFile()) {
        if (file.endsWith('.md') || file.endsWith('.jsonl') || file.endsWith('.json') || file.endsWith('.sql') || file.endsWith('.js') || file.endsWith('.txt')) {
          try {
            const content = fs.readFileSync(fullPath, 'utf8');
            if (content.includes(targetPhrase)) {
              console.log(`Found file: ${fullPath} (Size: ${stats.size} bytes)`);
            }
          } catch (e) {
            // ignore
          }
        }
      }
    }
  } catch (err) {
    // ignore
  }
}

for (const root of searchRoots) {
  console.log(`Searching in ${root}...`);
  searchDir(root);
}
console.log("Search finished.");
