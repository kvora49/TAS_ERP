const { Client } = require('pg');

const host = 'db.cxekeitxvfkukujselxr.supabase.co';
const port = 5432;
const user = 'postgres';
const password = 'tas_erp';
const database = 'postgres';

async function connectWithRetry(retries = 10, delay = 2000) {
  for (let i = 0; i < retries; i++) {
    const client = new Client({
      host,
      port,
      user,
      password,
      database,
      ssl: { rejectUnauthorized: false }
    });

    try {
      await client.connect();
      return client;
    } catch (err) {
      console.warn(`Connection attempt ${i + 1} failed: ${err.message}`);
      await client.end().catch(() => {});
      if (i < retries - 1) {
        await new Promise(res => setTimeout(res, delay));
      } else {
        throw err;
      }
    }
  }
}

async function run() {
  let client;
  try {
    client = await connectWithRetry();
    console.log("Connected.");

    console.log("Event Triggers:");
    const resTriggers = await client.query(`
      SELECT evtname, evtevent, evtenabled, evtfnum
      FROM pg_event_trigger;
    `);
    console.log(resTriggers.rows);

    console.log("Routines of type event_trigger:");
    const resRoutines = await client.query(`
      SELECT routine_name, routine_type, data_type
      FROM information_schema.routines
      WHERE data_type = 'event_trigger' OR routine_name LIKE '%rls%';
    `);
    console.log(resRoutines.rows);

  } catch (err) {
    console.error("Error:", err.message);
  } finally {
    if (client) {
      await client.end();
    }
  }
}

run();
