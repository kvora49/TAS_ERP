const fs = require('fs');
const path = require('path');

const logPath = 'C:\\Users\\Krish\\.gemini\\antigravity-ide\\brain\\a89a6bbb-83c4-4737-8fb0-e9ce0a1a1aac\\.system_generated\\logs\\transcript_full.jsonl';
const outputPath = path.join(__dirname, 'user_request_phase4.md');

try {
  const fileContent = fs.readFileSync(logPath, 'utf8');
  const lines = fileContent.split('\n');
  let found = false;
  for (const line of lines) {
    if (!line.trim()) continue;
    const parsed = JSON.parse(line);
    if (parsed && parsed.step_index === 0) {
      // Clean up <USER_REQUEST> tags if present
      let content = parsed.content;
      if (content.startsWith('<USER_REQUEST>')) {
        content = content.substring('<USER_REQUEST>'.length);
      }
      if (content.endsWith('</USER_REQUEST>')) {
        content = content.substring(0, content.length - '</USER_REQUEST>'.length);
      }
      fs.writeFileSync(outputPath, content.trim(), 'utf8');
      console.log("Success! Full request written to user_request_phase4.md");
      found = true;
      break;
    }
  }
  if (!found) {
    console.log("Error: step_index 0 not found");
  }
} catch (err) {
  console.error("Error:", err.message);
}
