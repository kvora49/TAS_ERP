# TAS ERP — Phase 4 Detailed Implementation Plan
**Production | Weeks 7–8 | 10 Working Days**

> ⚠️ AGENT INSTRUCTION: This document contains pixel-level UI specifications extracted from approved screens. Every color, layout, spacing, and behavior is prescribed. Do not deviate from any specification.

---

## Table of Contents
1. [Phase 4 Goals](#1-phase-4-goals)
2. [Design System Additions](#2-design-system-additions)
3. [Sidebar Structure Update](#3-sidebar-structure-update)
4. [Navigation & Route Map](#4-navigation--route-map)
5. [Screen Specifications](#5-screen-specifications)
6. [New Database Tables & SQL](#6-new-database-tables--sql)
7. [API Routes](#7-api-routes)
8. [Day-by-Day Execution Plan](#8-day-by-day-execution-plan)
9. [Phase 4 Completion Checklist](#9-phase-4-completion-checklist)

---

## 1. Phase 4 Goals

By end of Day 10 (Week 8), deployed and working:

- ✅ Sidebar updated with MASTER DATA and TRANSACTIONS and REPORTS section labels
- ✅ Workers: list (under Master Data) + Worker Profile (detail page with tabs)
- ✅ Production Lots: list with charts, 5-step wizard Create Lot, Lot Detail with stage progress tracker
- ✅ Edit Production Lot: 3-section form with stage assignment table
- ✅ Stage Entries: Add Stage Entry (5 sections), Stage Entry Detail (read-only)
- ✅ Job Work: Job Work List with 4 stat cards, Job Worker Ledger with donut chart
- ✅ Record Job Work Payment: full-page 3-section form with entry selection checklist

---

## 2. Design System Additions

### 2.1 New Color Tokens — add to globals.css

```css
/* Production status badges */
--badge-inprogress-bg: #DBEAFE;   --badge-inprogress-text: #1D4ED8;
--badge-completed-bg: #DCFCE7;    --badge-completed-text: #15803D;
--badge-onhold-bg: #FEF3C7;       --badge-onhold-text: #D97706;
--badge-cancelled-bg: #FEE2E2;    --badge-cancelled-text: #DC2626;
--badge-pending-bg: #F1F5F9;      --badge-pending-text: #64748B;
--badge-draft-bg: #F1F5F9;        --badge-draft-text: #64748B;

/* Stage type badges */
--badge-inhouse-bg: #DBEAFE;      --badge-inhouse-text: #1D4ED8;
--badge-jobwork-bg: #FEF3C7;      --badge-jobwork-text: #D97706;

/* Worker type badges */
--badge-jobworker-bg: #EDE9FE;    --badge-jobworker-text: #7C3AED;
--badge-permanent-bg: #DBEAFE;    --badge-permanent-text: #1D4ED8;

/* Job work payment status */
--badge-paid-bg: #DCFCE7;         --badge-paid-text: #15803D;
--badge-partial-bg: #FEF3C7;      --badge-partial-text: #D97706;
--badge-unpaid-bg: #FEE2E2;       --badge-unpaid-text: #DC2626;

/* Stage progress tracker */
--stage-completed-ring: #15803D;
--stage-completed-bg: #DCFCE7;
--stage-active-ring: #6366F1;
--stage-active-bg: #FFFFFF;
--stage-pending-ring: #D1D5DB;
--stage-pending-bg: #F9FAFB;
--stage-connector-done: #15803D;
--stage-connector-pending: #E5E7EB;

/* Progress bar */
--progress-bg: #E5E7EB;
--progress-fill-done: #15803D;
--progress-fill-active: #6366F1;
--progress-fill-zero: #E5E7EB;

/* Wizard step indicator */
--wizard-step-active-bg: #6366F1;
--wizard-step-done-bg: #15803D;
--wizard-step-pending-bg: #E5E7EB;
--wizard-step-line-done: #15803D;
--wizard-step-line-pending: #E5E7EB;

/* Attendance status */
--att-present-bg: #DCFCE7;        --att-present-text: #15803D;
--att-absent-bg: #FEE2E2;         --att-absent-text: #DC2626;
--att-halfday-bg: #FEF3C7;        --att-halfday-text: #D97706;
```

### 2.2 5-Step Wizard Header Component

Used in Create Production Lot:
```
Container: bg-white rounded-xl border border-[#E5E7EB] p-5 mb-6

Layout: flex items-center justify-between relative

Steps: 5 items connected by lines
Each step: flex flex-col items-center relative z-10

  Step circle:
    Active:    w-9 h-9 rounded-full bg-[#6366F1] text-white font-bold text-sm
               + ring-4 ring-[#EEF2FF]
    Done:      w-9 h-9 rounded-full bg-[#15803D] text-white — shows CheckCircle icon
    Pending:   w-9 h-9 rounded-full bg-[#E5E7EB] text-[#94A3B8] font-bold text-sm

  Step label (below circle, mt-2):
    Active:  text-xs font-semibold text-[#6366F1]
    Done:    text-xs font-medium text-[#15803D]
    Pending: text-xs text-[#94A3B8]

Connector line (between steps, absolute):
  height: 2px, top-4 (center of circles)
  Done:    bg-[#15803D]
  Pending: bg-[#E5E7EB]
```

### 2.3 Stage Progress Tracker Component

Used in Lot Detail — horizontal stage flow:
```
Container: flex items-start justify-between gap-0 mt-2 mb-6 relative

Each stage node: flex flex-col items-center gap-2 flex-1

  Circle:
    Completed: w-12 h-12 rounded-full bg-[#DCFCE7] border-3 border-[#15803D]
               CheckCircle2 icon size-6 text-[#15803D] inside
    Active:    w-12 h-12 rounded-full bg-white border-3 border-[#6366F1]
               stage number text-[#6366F1] font-bold text-lg inside
    Pending:   w-12 h-12 rounded-full bg-[#F9FAFB] border-2 border-[#D1D5DB]
               stage number text-[#94A3B8] font-bold text-lg inside

  Connector line (between circles):
    position absolute, top-6, between nodes
    Done → next:   h-0.5 bg-[#15803D]
    Active → next: h-0.5 bg-[#E5E7EB] (dashed)
    height: 2px, color as above

  Stage name: text-sm font-semibold text-[#0F172A] text-center mt-2
  Status badge: text-xs px-2.5 py-1 rounded-full
    Completed: bg-[#DCFCE7] text-[#15803D]
    In Progress: bg-[#DBEAFE] text-[#1D4ED8]
    Pending: bg-[#F1F5F9] text-[#64748B]
  Date (if entry exists): text-xs text-[#94A3B8] text-center
  Qty: text-xs text-[#64748B] text-center
```

### 2.4 Progress Bar with Percentage

Used in Production Lots table — Completed Qty column:
```
Layout: flex flex-col gap-1

Text row: flex items-center justify-between
  Left: "600 (50%)" text-sm font-medium text-[#374151]

Bar: h-1.5 rounded-full w-full bg-[#E5E7EB]
  Fill: h-full rounded-full
    100%: bg-[#15803D]
    >0%:  bg-[#6366F1]
    0%:   bg-[#E5E7EB] (no fill shown)
  Width: {percentage}%
```

### 2.5 Lot Summary Right Panel

Used in Create Lot, Add Stage Entry, Stage Entry Detail:
```
Container: bg-white rounded-xl border border-[#E5E7EB] p-5 sticky top-6

Title: flex items-center gap-2 text-base font-semibold text-[#0F172A] mb-4
  BarChart2 icon text-[#6366F1]

Design thumbnail (Create Lot only):
  w-full h-32 rounded-lg object-cover bg-[#F1F5F9] mb-4
  Shows design first image from R2

Key-value rows: flex items-center justify-between py-2 border-b border-[#F3F4F6] last:border-0
  Label: text-sm text-[#64748B]
  Value: text-sm font-medium text-[#374151]
  Special values:
    Quantity: text-[#6366F1] font-semibold
    Colour: flex items-center gap-2 — coloured dot (w-4 h-4 rounded-full) + text
```

### 2.6 Worker Avatar — Initials Circle

Workers don't have photos, they use initials:
```
Circle: w-14 h-14 rounded-full bg-[#6366F1] flex items-center justify-center
Text: text-xl font-bold text-white
  (first letters of each word in name, max 2 chars)
  e.g. "Shakti Sewing" → "SS"

In Workers List table: w-9 h-9 text-sm
In Worker Profile: w-16 h-16 text-2xl
```

### 2.7 Section Header inside Cards (Phase 4 variant)

Used in Stage Entry Detail, Worker Profile sections:
```
Each section is a card with a colored left-border icon:

Icon container: w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0
Icon: size-[18px]

Section variants and colors:
  Quantity Details:     bg-[#EEF2FF] icon text-[#6366F1]   Package icon
  Job Work Details:     bg-[#F0FDF4] icon text-[#16A34A]   IndianRupee icon
  Worker Assignment:    bg-[#EEF2FF] icon text-[#6366F1]   Users icon
  Additional Info:      bg-[#FEF9C3] icon text-[#D97706]   FileText icon
  Timeline:             bg-[#EEF2FF] icon text-[#6366F1]   Clock icon
  Personal Information: bg-[#EEF2FF] icon text-[#6366F1]   User icon
  Employment:           bg-[#F0FDF4] icon text-[#16A34A]   Briefcase icon
  Bank & Salary:        bg-[#FEF9C3] icon text-[#D97706]   CreditCard icon
```

### 2.8 Horizontal Timeline (Stage Entry Detail bottom)

Used in Stage Entry Detail Section 5:
```
Container: flex items-start gap-0 overflow-x-auto

4 steps side by side:
  Step: flex flex-col items-center gap-2 flex-1

  Circle: w-8 h-8 rounded-full bg-[#DCFCE7] border-2 border-[#15803D]
          Check icon inside text-[#15803D] size-4

  Connector: h-0.5 bg-[#15803D] flex-1 mt-4 (between circles)

  Label: text-xs font-semibold text-[#374151] text-center
  DateTime: text-xs text-[#94A3B8] text-center mt-1
  Time: text-xs text-[#94A3B8] text-center
```

---

## 3. Sidebar Structure Update

The sidebar needs a significant restructure for Phase 4. Update Sidebar.tsx completely:

```
[Logo: TAS ERP]

Dashboard                      Home icon

Master Data ▸                  Settings2 icon (expandable)
  • Brands
  • Godowns
  • Production Stages
  • Size Sets
  • Designs
  • Expense Types
  • GST Rates
  • Banks & UPI
  • Raw Materials
  • Parties
  • Workers                    ← NEW Phase 4 (under Master Data)
  • Units                      ← NEW Phase 4 stub

─── TRANSACTIONS ───          (section label)

Raw Materials                  Package icon (top-level)

Production ▸                   Factory icon (expandable)
  • Production Lots
  • Stage Entries
  • Job Work ▸
      - Job Work List
      - Job Worker Ledger
      - Record Payment

Dispatch                       Truck icon (Coming Soon)
Stock                          Boxes icon (Coming Soon)
Payments                       CreditCard icon (top-level)

─── REPORTS ───               (section label)

Production Reports             BarChart3 icon
Job Work Reports               ClipboardList icon
Stock Reports                  Package icon

Settings                       Settings icon
```

### Job Work sub-menu:
```
Job Work is expandable under Production:
  Job Work List       → /production/job-work/list
  Job Worker Ledger   → /production/job-work/ledger
  Record Payment      → /production/job-work/record-payment

Active state: same bg-[#312E81] text-white as all other active items
Sub-sub items are indented one more level: pl-12 (vs pl-9 for normal sub-items)
```

---

## 4. Navigation & Route Map

```
Master Data:
  /master-data/workers           → Workers List
  /master-data/workers/new       → Add Worker (form)
  /master-data/workers/[id]      → Worker Profile
  /master-data/workers/[id]/edit → Edit Worker

Production:
  /production/lots               → Production Lots List
  /production/lots/new           → Create Production Lot (wizard)
  /production/lots/[id]          → Lot Detail
  /production/lots/[id]/edit     → Edit Production Lot
  /production/stage-entries      → Stage Entries list
  /production/stage-entries/new  → Add Stage Entry
  /production/stage-entries/[id] → Stage Entry Detail

Job Work:
  /production/job-work/list             → Job Work List
  /production/job-work/ledger           → Job Worker Ledger (with worker param)
  /production/job-work/ledger/[workerId] → Specific worker ledger
  /production/job-work/record-payment   → Record Job Work Payment
```

---

## 5. Screen Specifications

---

### 5.1 Workers List — `/master-data/workers`

**Page title:** "Workers List"
**Breadcrumb:** Master Data > Workers > Workers List
**Header buttons:** "Export" (outline, Download icon) + "+ Add Worker" (primary)

---

#### FILTER BAR (top, no stat cards before it)

```
flex items-center gap-4 mb-4

Worker Type dropdown: "All Types" / Job Worker / Permanent    w-[200px]
Status dropdown:      "Active" (default) / Inactive           w-[200px]
Search input (flex-1): "Search by Name, Phone, Worker ID..."
Clear Filters link:   text-sm text-[#6366F1] hover:underline (right-aligned, only when filters active)
```

---

#### 4 STAT CARDS (grid grid-cols-4 gap-4 mb-6)

```
Card 1: Total Workers
  Icon: Users, bg-[#EEF2FF], color #6366F1
  Value: "58" text-2xl font-bold
  Sub: "All Types" text-xs text-[#64748B]

Card 2: Job Workers
  Icon: Scissors (or Wrench), bg-[#F0FDF4], color #16A34A
  Value: "42" text-2xl font-bold
  Sub: "Active" text-xs text-[#64748B]

Card 3: Permanent Workers
  Icon: UserCheck, bg-[#FFF7ED], color #EA580C
  Value: "16" text-2xl font-bold
  Sub: "Active" text-xs text-[#64748B]

Card 4: Inactive Workers
  Icon: UserX, bg-[#FEF2F2], color #DC2626
  Value: "3" text-2xl font-bold
  Sub: "Inactive" text-xs text-[#64748B]
```

---

#### WORKERS TABLE

```
Title row: flex items-center justify-between mb-3
  "Workers" text-sm font-semibold text-[#374151]
  "Showing 1 to 10 of 58 workers" | "10 per page" dropdown

Columns: # | Worker ID | Name | Type | Phone | Rate (Per Pc) | Status | Bank Account | Actions

#: w-10 text-sm text-[#64748B]
Worker ID: text-sm font-mono text-[#374151] — "JW-0007" / "PW-0001"
Name: text-sm font-medium text-[#0F172A]
Type:
  Job Worker: text-sm text-[#374151] (plain text, not badge)
  Permanent: text-sm text-[#374151] (plain text)
Phone: text-sm text-[#374151]
Rate (Per Pc): text-sm text-[#374151]
  Job Worker: "₹12.00"
  Permanent:  "₹0.00" text-[#94A3B8]
Status: StatusBadge — Active green / Inactive red
Bank Account: text-sm text-[#374151] — "HDFC - 50200012345678" (truncated format)

Actions: flex items-center gap-2
  Eye icon (view profile): w-8 h-8 border border-[#E5E7EB] rounded-lg
  ⋮ MoreVertical: w-8 h-8 border border-[#E5E7EB] rounded-lg
    Dropdown: Edit | Deactivate | View Ledger

FOOTER: pagination + 10 per page selector
```

---

### 5.2 Worker Profile — `/master-data/workers/[id]`

**Page title:** "Worker Profile"
**Breadcrumb:** Master Data > Workers > Worker Profile
**Header buttons:** "← Back to Workers" (outline, ArrowLeft) + "Edit Worker" (outline, Pencil) + "+ Add New Worker" (primary)

---

#### WORKER HEADER CARD

```
Layout: flex items-start gap-6 bg-white rounded-xl border border-[#E5E7EB] p-6 mb-4

LEFT — Avatar + basic info:
  Initials circle: w-16 h-16 rounded-full bg-[#EDE9FE] text-[#7C3AED] text-2xl font-bold
  Name: text-xl font-bold text-[#0F172A]
  "Job Worker" badge: bg-[#EDE9FE] text-[#7C3AED] text-xs font-medium px-2.5 py-1 rounded-md
  Phone: flex items-center gap-1.5 text-sm text-[#374151] mt-2
  Email: flex items-center gap-1.5 text-sm text-[#64748B] mt-1
  Address: flex items-center gap-1.5 text-sm text-[#64748B] mt-1 (MapPin icon)

CENTER — Worker details grid (grid grid-cols-3 gap-x-8 gap-y-2):
  Worker ID:    JW-0007
  Type:         Job Worker
  Rate (Per Pc): ₹12.00
  Status:       Active badge
  Date Joined:  15 Mar 2024
  Created On:   15 Mar 2024
  Joined (sub): text-xs text-[#94A3B8] below "Joined" label — blurred/redacted date in screen

RIGHT — Current Status card (bg-[#F8FAFC] rounded-xl p-4 min-w-[220px]):
  "Current Status" title text-sm font-semibold text-[#0F172A]
  ⋮ button top-right
  Status: Active badge
  Total Job Work: 42 (count)
  Total Paid: ₹1,85,300.00 text-[#15803D] font-semibold
  Outstanding: ₹60,480.00 text-[#DC2626] font-bold
  Last Work Date: 24 May 2024
```

---

#### TABS

```
Tab bar: flex border-b border-[#E5E7EB] mb-6
Tabs: Overview | Job Work History | Payments | Attendance | Documents
Active: text-[#6366F1] border-b-2 border-[#6366F1] font-semibold
```

---

#### OVERVIEW TAB — 3 Info Cards (grid grid-cols-3 gap-6)

**Card 1 — Personal Information:**
```
Section header (Section 2.7): User icon, "Personal Information", ⋮ menu top-right
Rows (label: text-sm text-[#64748B], value: text-sm text-[#374151]):
  Contact Person | Phone | Email | Address
  GST No. | PAN No. | Aadhaar No.
```

**Card 2 — Employment Information:**
```
Section header: Briefcase icon, "Employment Information", ⋮ menu
Rows:
  Worker Type | Working Since | Default Rate (Per Pc)
  Specialization | Preferred Stage | Max Capacity (Per Day)
  Remarks
```

**Card 3 — Bank & Salary Information:**
```
Section header: CreditCard icon, "Bank & Salary Information", ⋮ menu (...)
Rows:
  Bank Name | Account No. | IFSC Code | Account Holder Name
  Payment Mode: "Bank Transfer" badge → bg-[#DBEAFE] text-[#1D4ED8]
  Payment Cycle: "Weekly"
  Current Outstanding: ₹60,480.00 text-[#DC2626] font-bold
```

---

#### ATTENDANCE SUMMARY (below 3 cards)

```
Grid grid-cols-2 gap-6

LEFT — Attendance Summary (This Month):
  Title: "Attendance Summary (This Month)" text-sm font-semibold
  
  4 stat tiles (grid grid-cols-4 gap-3 mb-4):
    Total Days: "26" text-2xl font-bold
    Present: "24" text-2xl font-bold text-[#15803D]
    Half Day: "1" text-2xl font-bold text-[#D97706]
    Absent: "1" text-2xl font-bold text-[#DC2626]

  Attendance table:
    Columns: Date | Status | Check In | Check Out | Total Hours
    Status badge: Present=green / Absent=red / Half Day=orange
    
  "View Full Attendance →" link: text-sm text-[#6366F1] mt-3

RIGHT — Leave Summary (This Year):
  Title: "Leave Summary (This Year)" text-sm font-semibold
  
  6 stat tiles (grid grid-cols-3 gap-3 mb-4):
    Total Leaves: "12"
    Taken: "6" text-[#DC2626]
    Pending: "0" text-[#D97706]
    Available: "6" text-[#15803D]

  Leave table:
    Columns: Leave Type | Entitled | Taken | Pending | Available
    Leave types: Casual Leave / Sick Leave / Festival Leave / Paid Leave

  "View Leave History →" link: text-sm text-[#6366F1] mt-3
```

---

#### RIGHT SIDE PANELS (sticky, alongside tabs content)

```
RIGHT — Quick Contact:
  Card: bg-white rounded-xl border border-[#E5E7EB] p-4
  Title: "Quick Contact" text-sm font-semibold mb-3
  Each: flex items-center justify-between
    Phone: text-sm + Phone icon button (call)
    Email: text-sm text-[#6366F1] + Mail icon button
    Location: text-sm + ExternalLink icon button

RIGHT — Documents: (below Quick Contact)
  Title: "Documents" text-sm font-semibold + "View All" link right
  Each doc: flex items-center justify-between py-2.5 border-b border-[#F3F4F6]
    FileText icon + doc name + upload date | Download icon button
  Docs: Aadhaar Card / PAN Card / Bank Passbook

RIGHT — Notes: (below Documents)
  ⋮ menu top-right
  Note text: text-sm text-[#374151] italic
  Added by + date: text-xs text-[#94A3B8] mt-2
```

---

### 5.3 Production Lots List — `/production/lots`

**Page title:** "Production Lots"
**Breadcrumb:** Production > Production Lots (no breadcrumb shown — just page title)
**Subtitle:** "View and manage all production lots"
**Header buttons:** Tutorial (outline, Play icon) + Notification bell + SA avatar | "+ Create Lot" (primary, Plus icon)

---

#### 5 STAT CARDS (grid grid-cols-5 gap-4 mb-4)

```
Card 1: Total Lots
  Icon: ClipboardList, bg-[#EEF2FF], color #6366F1
  Value: "128" text-2xl font-bold
  Sub: "All time"

Card 2: In Progress
  Icon: Clock, bg-[#DBEAFE], color #1D4ED8
  Value: "68" text-2xl font-bold text-[#1D4ED8]
  Sub: "53.13%" text-xs font-medium text-[#1D4ED8]

Card 3: Completed
  Icon: CheckCircle2, bg-[#DCFCE7], color #15803D
  Value: "42" text-2xl font-bold text-[#15803D]
  Sub: "32.81%" text-xs font-medium text-[#15803D]

Card 4: On Hold
  Icon: PauseCircle, bg-[#FEF3C7], color #D97706
  Value: "8" text-2xl font-bold text-[#D97706]
  Sub: "6.25%" text-xs font-medium text-[#D97706]

Card 5: Cancelled
  Icon: XCircle, bg-[#FEE2E2], color #DC2626
  Value: "10" text-2xl font-bold text-[#DC2626]
  Sub: "7.81%" text-xs font-medium text-[#DC2626]
```

---

#### FILTER BAR

```
flex items-center gap-3

Search input: "Search by Lot No. or Design..." flex-1
Brand dropdown:  "All Brands"   w-[160px]
Design dropdown: "All Designs"  w-[160px]
Status dropdown: "All Status"   w-[160px]
Date Range picker: w-[220px]
Filters button: border outline SlidersHorizontal icon + "Filters" (right-aligned)
```

---

#### PRODUCTION LOTS TABLE

```
Columns: Lot No. | Brand | Design | Colour | Size Set | Total Qty | Completed Qty | Status | Start Date | Due Date | Actions

Lot No.: text-sm font-mono text-[#6366F1] hover:underline cursor-pointer (link to lot detail)
         e.g. "LOT-24-05-001"
Brand: text-sm text-[#374151]
Design: text-sm text-[#374151]
Colour: text-sm text-[#374151]
Size Set: text-sm text-[#374151] — "S, M, L, XL"
Total Qty: text-sm text-right text-[#374151]

Completed Qty (SPECIAL COLUMN — 2-row layout):
  Row 1: "600 (50%)" text-sm font-medium text-[#374151]
  Row 2: Progress bar (Section 2.4) — full width of cell
         100% fills → green bg-[#15803D]
         partial → purple bg-[#6366F1]
         0% → gray bg-[#E5E7EB]

Status badge:
  In Progress: bg-[#DBEAFE] text-[#1D4ED8]
  Completed:   bg-[#DCFCE7] text-[#15803D]
  On Hold:     bg-[#FEF3C7] text-[#D97706]
  Cancelled:   bg-[#FEE2E2] text-[#DC2626]
  Draft:       bg-[#F1F5F9] text-[#64748B]

Start Date: text-sm text-[#374151]
Due Date: text-sm text-[#374151]

Actions: flex items-center gap-2
  Eye: w-8 h-8 border border-[#E5E7EB] rounded-lg (view lot detail)
  ⋮ MoreVertical: same — dropdown: Edit | Add Stage Entry | Put on Hold | Cancel

FOOTER: "Showing 1 to 5 of 128 entries" + pagination | "5 / page" dropdown
```

---

#### BOTTOM SECTION (grid grid-cols-3 gap-6 mt-6)

```
LEFT — Lots by Status (donut chart):
  Title: "Lots by Status" text-sm font-semibold
  Recharts PieChart with innerRadius
  Legend: each status with colored dot + name + count + percentage
    In Progress: #6366F1 | Completed: #15803D | On Hold: #D97706 | Cancelled: #DC2626

CENTER — Top Designs (By Lots):
  Title: "Top Designs (By Lots)" text-sm font-semibold
  Simple table (no border, just rows):
    Columns: Design | Total Lots
    5 rows shown
    Design: text-sm text-[#374151]
    Total Lots: text-sm font-medium text-[#0F172A] text-right
  "View all designs →" link: text-sm text-[#6366F1] mt-3

RIGHT — Recent Activity:
  Title: "Recent Activity" text-sm font-semibold
  "View All" link right-aligned text-sm text-[#6366F1]
  Each activity: flex items-start gap-3 py-3 border-b border-[#F3F4F6] last:border-0
    Icon: w-8 h-8 rounded-full flex items-center justify-center
      Completed: bg-[#DCFCE7] CheckCircle icon text-[#15803D]
      Stage entry: bg-[#DBEAFE] ClipboardList icon text-[#1D4ED8]
      On Hold: bg-[#FEF3C7] PauseCircle icon text-[#D97706]
      Cancelled: bg-[#FEE2E2] XCircle icon text-[#DC2626]
    Content:
      Action text: text-sm text-[#374151]
      "by [User]": text-xs text-[#64748B] mt-0.5
    Right: time ago text-xs text-[#94A3B8]
```

---

### 5.4 Create Production Lot — `/production/lots/new`

**Page title:** "Create Production Lot"
**Breadcrumb:** Production > Production Lots > Create Lot
**Header buttons:** Tutorial (outline) + notification bell + "Save as Draft" (outline) + "Create Lot" (primary, Checkmark icon)

**Layout:** 5-step wizard header + main form area + right Lot Summary panel

---

#### WIZARD STEPS HEADER

```
5 steps in horizontal row with connecting lines:
1. Basic Details (circle "1")
2. Lot Specifications (circle "2" — greyed out for now, all on one page in this reference)
3. Size Set & Quantity (circle "3")
4. Assign Stages (circle "4")
5. Review & Create (circle "5")

Implementation note: All steps shown on single page based on reference screen.
Step circles use the 5-Step Wizard Header Component (Section 2.2).
```

---

#### SECTION: Basic Information

```
Card: bg-white rounded-xl border border-[#E5E7EB] p-6 mb-4
Title: "Basic Information" with ClipboardList icon bg-[#EEF2FF] (Section header pattern)

Grid grid-cols-4 gap-4:
  Brand *            [select with brand logo thumbnail]
  Design *           [searchable select — "Design 1002 - Polo T Shirt"]
  Lot No. *          [text input — auto-generated "LOT-24-05-006", with refresh/regenerate icon button right-inside]
  Lot Date *         [date picker]

Grid grid-cols-4 gap-4 mt-4:
  Colour *           [select — shows color dot + name: ● Red]
  Season/Collection  [select: "Summer 2024"]
  Buyer/Order (Optional) [searchable select: "Order #ORD-24-1185"]
  Target Dispatch Date * [date picker]
```

---

#### SECTION: Size Set & Quantity

```
Card: bg-white rounded-xl border border-[#E5E7EB] p-6 mb-4
Title: "Size Set & Quantity" with Boxes icon bg-[#DBEAFE]

RIGHT of title: "Total Quantity: 1,200 Pcs" text-sm font-semibold text-[#6366F1]

Size/Quantity table:
  Row header: Size | [S] | [M] | [L] | [XL] | [XXL] | Total
  Row data:   Quantity (Pcs) | [number input per size] | [computed total, read-only bold]

  Size headers: text-sm font-medium text-[#374151] text-center
  Number inputs: w-full h-9 text-center border border-[#E5E7EB] rounded-lg text-sm
  Total: text-sm font-bold text-[#0F172A] text-center bg-[#F9FAFB] rounded

Bottom row (flex gap-4 mt-3):
  "+ Add Size" text button: Plus icon text-[#6366F1] + "Add Size"
  "Load Size Template" text button: ClipboardList icon text-[#6366F1] + "Load Size Template"
  "Use same for all colours" checkbox (right-aligned): Checkbox + label text-sm
```

---

#### SECTION: Assign Production Stages

```
Card: bg-white rounded-xl border border-[#E5E7EB] p-6 mb-4
Title: "Assign Production Stages" with GitBranch icon bg-[#EDE9FE]
Subtitle: "Select and order the stages for this lot" text-sm text-[#64748B]
Right: "Total Stages: 6" badge bg-[#EEF2FF] text-[#6366F1]

Stage assignment table:
  Columns: [drag handle] | # | Stage Name | Stage Type | Sequence | Required

  Drag handle: GripVertical icon text-[#94A3B8]
  #: row number text-sm text-[#64748B]
  Stage Name: text-sm font-medium text-[#374151]
  Stage Type badge:
    In-house: bg-[#DBEAFE] text-[#1D4ED8]
    Job Work: bg-[#FEF3C7] text-[#D97706]
  Sequence: flex items-center gap-1
    Down arrow button + number input (w-14 h-8 text-center) + Up arrow button
    Arrow buttons: w-7 h-7 border border-[#E5E7EB] rounded
  Required: Toggle switch (ON=purple, OFF=gray)

"+ Add Stage" button (below table):
  border border-[#E5E7EB] bg-white h-9 px-3 rounded-lg text-sm Plus icon + "Add Stage"

Bottom checkbox row:
  "Allow rework for this lot" Checkbox + label + Info tooltip icon
```

---

#### RIGHT COLUMN (grid grid-cols-3: main=2cols, right=1col)

**Lot Summary Panel (Section 2.5):**
```
Title: "Lot Summary" with BarChart2 icon

Design thumbnail: w-full h-28 rounded-lg object-cover (design image from R2)

Key-value rows:
  Brand:           [selected brand name]
  Design:          [selected design name]
  Colour:          ● Red (color dot)
  Total Quantity:  1,200 Pcs (text-[#6366F1] font-semibold)
  Size Set:        S, M, L, XL, XXL
  Stages Assigned: 6 Stages
  Target Dispatch: 20 Jun 2024
  Lot No.:         LOT-24-05-006
```

**Estimated Timeline Card (below Lot Summary):**
```
Title: "Estimated Timeline" with Calendar icon bg-[#FEF3C7] text-[#D97706]

Rows:
  Start Date:     31 May 2024
  Est. Completion: 19 Jun 2024 (text-[#15803D] font-semibold)
  Duration:       20 Days

Progress bar: full width
  Orange/amber gradient from left: bg-gradient-to-r from-[#F59E0B] to-[#FCD34D]
  Width: based on current progress (0% for new lot)
  h-2 rounded-full bg-[#E5E7EB] as background
```

**Next Steps Card (below Estimated Timeline):**
```
Title: "Next Steps" text-sm font-semibold text-[#0F172A] mb-3

3 items with circle indicators:
  ✅ Review and confirm details     — green filled circle
  ○ Create lot to generate lot records — empty circle (pending)
  ○ Add stage entries as production starts — empty circle
```

**Additional Details Card (in main area, left side):**
```
Title: "Additional Details" with Settings icon bg-[#F0FDF4] text-[#16A34A]

Grid grid-cols-2 gap-4:
  Production Type: [select: Regular Production / Sample / Rework]
  Priority: [select with icon: 🔴 High / 🟡 Normal / 🟢 Low]
  
Remarks: textarea h-20 resize-none

Custom Fields:
  Shows custom fields defined for this brand/lot type
  Example: Customer Ref. No. [text] | PO Date [date]

Internal Notes: textarea h-16 resize-none

Attachments: dropzone
  Any uploaded files shown below as chips: filename + size + × remove
```

---

#### WIZARD FOOTER

```
flex items-center justify-between border-t border-[#E5E7EB] pt-4 mt-4

Left: "Back" button (outline, ArrowLeft icon) — disabled on step 1
Right: "Save as Draft" (outline) + "Next: Review & Create →" (primary) OR "Create Lot" on final step
```

---

### 5.5 Lot Detail — `/production/lots/[id]`

**Page title:** "Lot Detail"
**Breadcrumb:** Production > Production Lots > LOT-24-05-001
**Header buttons:** "← Back to List" (outline) + "Edit Lot" (outline, Pencil) + "Mark Lot Complete" (primary, CheckCircle icon)

---

#### LOT HEADER CARD

```
Full-width card: bg-white rounded-xl border border-[#E5E7EB] p-5 mb-6

Layout: grid grid-cols-7 gap-6

Col 1: Lot No. header
  "LOT-24-05-001" text-2xl font-bold text-[#0F172A]
  Status badge: "In Progress" bg-[#DBEAFE] text-[#1D4ED8] — inline next to lot no.

Cols 2-6: Info grid (grid grid-cols-5 gap-4 text-sm):
  Brand | Design | Colour | Size Set | Total Quantity | Completed Quantity
  Each: label text-xs text-[#64748B] uppercase tracking-wide + value text-sm font-semibold

  Colour: flex items-center gap-2 — ● Red (colored dot)
  Completed: "600 (50%)" with percentage

Row 2 (below): Start Date | Due Date | Created By | Created On | Last Updated

Col 7 (rightmost):
  Design image: w-32 h-36 rounded-xl object-cover bg-[#F1F5F9]
  (shows design first image from R2, or placeholder shirt icon)
```

---

#### STAGE PROGRESS TRACKER

```
Title: "Production Stages Progress" text-base font-semibold text-[#0F172A] mb-4

Horizontal tracker (Section 2.3):
  Shows all lot stages (from lot_production_stages table)
  Example: Cutting (Completed) → Stitching (In Progress) → Finishing (Pending) → Packing (Pending)

  Between circles: connector line — solid green if left stage done, dashed gray if not yet

Each stage node shows below:
  Stage name: text-sm font-semibold text-center
  Status badge: Completed / In Progress / Pending
  Date: text-xs text-[#94A3B8] (date of last stage entry for that stage)
  Qty: text-xs text-[#64748B] "Qty: 600 / 1,200"
```

---

#### MAIN CONTENT AREA (grid grid-cols-3: left=2, right=1)

**Stage Entries Table (left 2 cols):**
```
Header row: flex items-center justify-between mb-3
  "Stage Entries" text-sm font-semibold
  "+ Add Stage Entry" button: primary small h-9 px-3

Table columns: # | Stage | Entry Date | Qty In | Qty Out | Wastage | Job Work Rate | Worker | Status | Actions

# : w-10 text-sm text-[#64748B]
Stage: text-sm font-medium text-[#374151]
Entry Date: text-sm text-[#374151]
Qty In: text-sm text-right text-[#374151]
Qty Out: text-sm text-right text-[#374151]
  "-" shown if entry not yet done
Wastage: text-sm text-right text-[#D97706]
  "20 (1.67%)" format
  "-" if not done
Job Work Rate: text-sm text-right text-[#374151]
  "₹ 4.00" format
Worker: text-sm text-[#374151]
  Shakti Tailors / Shakti Sewing / "-" if pending
Status badge:
  Completed: bg-[#DCFCE7] text-[#15803D]
  In Progress: bg-[#DBEAFE] text-[#1D4ED8]
  Pending: bg-[#F1F5F9] text-[#64748B]
Actions: Eye icon button only (view stage entry detail)

FOOTER: "Showing 1 to 4 of 4 entries"
```

**Lot Summary Panel (right 1 col, sticky):**
```
Title: "Lot Summary" text-sm font-semibold text-[#0F172A] mb-4
(No icon here — plain title)

Key-value rows (flex justify-between py-2.5 border-b border-[#F3F4F6] last:border-0):
  Total Quantity:       1,200
  Completed Quantity:   600 (50%) — text-[#15803D] font-semibold
  In Progress Quantity: 600 (50%) — text-[#1D4ED8] font-semibold
  Pending Quantity:     0 (0%) — text-[#94A3B8]
  Total Stages:         4
  Completed Stages:     1
  In Progress Stages:   1
  Pending Stages:       2
```

---

#### BOTTOM NOTE BANNER

```
Blue info banner (full width):
"Note: Mark the lot as complete once all stages are finished and quantities are verified."
```

---

### 5.6 Edit Production Lot — `/production/lots/[id]/edit`

**Page title:** "Edit Production Lot"
**Breadcrumb:** Production > Production Lots > LOT-24-05-001 > Edit Lot
**Header buttons:** "← Back to Detail" (outline) + "Save Changes" (primary, Save icon)

**Layout:** 3 numbered sections + right Lot Summary panel

---

#### SECTION 1 — Lot Information (numbered circle "1")

```
Card: bg-white rounded-xl border border-[#E5E7EB] p-6 mb-4
Title: "Lot Information" (plain, no colored icon — text-sm font-semibold text-[#0F172A])
Subtitle: "Update the details of this production lot." text-xs text-[#64748B] mt-1

Grid grid-cols-4 gap-4:
  Brand *    [select, pre-filled]
  Design *   [select, pre-filled]
  Colour *   [select with color dot, pre-filled: ● Red]
  Size Set * [select, pre-filled: "S, M, L, XL"]

Grid grid-cols-4 gap-4 mt-4:
  Lot No.            [text, read-only — shows "Auto generated" helper below, bg-[#F9FAFB]]
  Total Quantity *   [number, editable]
  Target Start Date * [date picker]
  Target Due Date *  [date picker]

Notes (Optional) — full width, mt-4:
  Textarea h-24, 45/250 char counter bottom-right
```

---

#### SECTION 2 — Quantity Breakdown by Size (numbered circle "2")

```
Title: "Quantity Breakdown by Size"
Subtitle: "Update quantity for each size in the selected size set."

Size quantity table (same as Create Lot):
  Header: Size | S | M | L | XL | Total
  Inputs: number inputs per size
  Total: computed, read-only, bg-[#F9FAFB]

Footer: "Total Quantity: 1,200" text-sm font-semibold text-[#6366F1]
```

---

#### SECTION 3 — Assign Production Stages (numbered circle "3")

```
Title: "Assign Production Stages"
Subtitle: "Add, remove or reorder stages for this lot."

Stage assignment table (different from Create):
  Columns: [drag handle] | # | Stage (select) | Description (text) | Is Mandatory (toggle) | Actions (trash)

  Each row:
    Drag handle: GripVertical text-[#94A3B8]
    #: row number
    Stage: select dropdown
    Description: text input
    Is Mandatory: Toggle switch
    Actions: Trash2 icon text-[#EF4444]

"+ Add Stage" button below table

NOTE BANNER (blue, inside section):
  "Changes will be reflected in the lot and related upcoming stage entries."
```

---

#### RIGHT — Lot Summary Panel

```
Same structure as Create Lot summary, but showing current values:
  Brand | Design | Colour | Size Set | Total Quantity | Target Start | Target Due
  Total Stages | Completed Stages | In Progress Stages | Pending Stages

NOTE BANNER (yellow, inside panel):
  "Changes will be reflected in the lot and related upcoming stage entries."
```

---

### 5.7 Add Stage Entry — `/production/stage-entries/new`

**Page title:** "Add Stage Entry"
**Breadcrumb:** Production > Stage Entries > Add Stage Entry
**Header buttons:** "← Back to Lot Detail" (outline) + "Save Entry" (primary, Save icon)

**Layout:** 5 numbered sections + right panel (Lot Summary + Stage Summary + Financial Summary + Note)

---

#### SECTION 1 — Lot & Stage Information (numbered circle "1")

```
Grid grid-cols-4 gap-4:
  Lot No. *   [searchable select — "LOT-24-05-001"]
  Stage *     [select — "2 - Stitching" (number: name format)]
  Entry Date * [date picker]
  Shift       [select: "Day Shift (9:00 AM - 6:00 PM)" / Night Shift / Custom]

INFO ROW (below fields, full-width gray bar):
  bg-[#F9FAFB] rounded-lg px-4 py-3 border border-[#E5E7EB]
  flex items-center gap-8 text-sm:
    Brand: [value]
    Design: [value]
    Colour: ● [value]
    Size Set: [value]
    Total Lot Qty: [value]
    Completed Qty: "[value] ([prev stage])" — shows completed from previous stage
    Pending Qty: [value]
  All: label text-xs text-[#64748B] + value text-sm font-medium text-[#374151]
```

---

#### SECTION 2 — Quantity Details (numbered circle "2")

```
Grid grid-cols-5 gap-4:
  Qty In (From Prev. Stage) * [number — auto-filled from previous stage Qty Out]
  Qty Processed / Out *        [number — editable]
  Wastage Qty                  [number — auto-computed: Qty In - Qty Out]
  Wastage %                    [read-only computed: (Wastage/QtyIn)*100, shown as "2.12%", bg-[#F9FAFB]]
  Qty Balance                  [read-only: QtyIn - QtyOut - Wastage, bg-[#F9FAFB]]
```

---

#### SECTION 3 — Job Work Details (numbered circle "3")

```
Grid grid-cols-4 gap-4:
  Job Work Type   [select: Stitching / Cutting / Finishing etc. — matches stage]
  Job Work Rate (Per Pc) [number input with ₹ prefix — "₹ 12.00"]
  Total Job Work Amount  [computed read-only: QtyOut × Rate, "₹ 13,440.00", bg-[#F9FAFB]]
  Payment Type    [select: Piece Rate / Fixed / Per Day]
```

---

#### SECTION 4 — Worker Assignment (numbered circle "4")

```
Grid grid-cols-4 gap-4:
  Worker / Tailor * [searchable select from workers table]
  Worker Type       [read-only, auto-fills: "Job Worker", text-[#64748B], bg-[#F9FAFB]]
  No. of Workers    [number input]
  Total Labor Cost  [computed read-only: ₹[amount], bg-[#F9FAFB]]
```

---

#### SECTION 5 — Additional Information (numbered circle "5")

```
Grid grid-cols-3 gap-4:

Col 1 — Remarks:
  Label: "Remarks (Optional)"
  Textarea: h-28 resize-none
  Character counter: "44 / 250" bottom-right text-xs text-[#94A3B8]

Col 2 — Custom Fields:
  Label: "Custom Fields"
  Shows custom fields defined for the selected stage
  Example:
    "Thread Colour" → select input (value: "White")
    "Machine Used" → text input (value: "JUKI DDL-8700")

Col 3 — Attachments:
  Label: "Attachments (Optional)"
  Dropzone (compact version):
    CloudUpload icon + "Drag & drop files here or click to browse"
    "JPG, PNG, PDF (Max. 5MB)"
```

---

#### RIGHT PANEL (sticky, 3 stacked cards)

**Lot Summary:**
```
Title: "Lot Summary" text-sm font-semibold + ClipboardList icon text-[#6366F1]
Rows: Lot No. | Design | Colour | Size Set
      Total Lot Quantity | Completed Quantity | Pending Quantity
```

**Stage Summary (for selected stage):**
```
Title: "Stage Summary ([Stage Name])" text-sm font-semibold + GitBranch icon text-[#6366F1]
Rows:
  Expected In Qty:  [from previous stage Qty Out]
  Qty Out (This Entry): [live-updating from Section 2]
  Wastage Qty:      [live-updating]
  Balance Qty:      [live-updating]
```

**Financial Summary:**
```
Title: "Financial Summary" text-sm font-semibold + IndianRupee icon text-[#15803D]
Rows:
  Rate (Per Pc):         ₹12.00
  Total Job Work Amount: ₹13,440.00 (live-updates)
  Labor Cost:            ₹13,440.00
```

**Note Card:**
```
bg-[#F0FDF4] border border-[#DCFCE7] rounded-xl p-4
CheckCircle icon text-[#15803D] + "Note" title
"After saving, the quantity will be updated and available for the next stage."
text-sm text-[#374151]
```

---

### 5.8 Stage Entry Detail — `/production/stage-entries/[id]`

**Page title:** "Stage Entry Detail"
**Breadcrumb:** Production > Stage Entries > Entry Detail > SE-24-05-0025
**Header buttons:** "← Back to List" + "Print" + "Edit Entry" (primary)

---

#### ENTRY HEADER CARD

```
Full-width card: bg-white rounded-xl border border-[#E5E7EB] p-5 mb-6

Layout: flex items-center gap-6

LEFT — Entry number + status:
  FileText icon in w-12 h-12 rounded-xl bg-[#EEF2FF] color #6366F1
  "SE-24-05-0025" text-xl font-bold text-[#0F172A]
  Status badge: "Completed" bg-[#DCFCE7] text-[#15803D] — inline

RIGHT — Info grid (grid grid-cols-6 gap-6 text-sm):
  Lot No. | Stage | Entry Date | Shift | Created By | Created On
  Each: label text-xs text-[#64748B] + value text-sm font-medium text-[#374151]
  Stage shows: "2 - Stitching"
  Shift shows: "Day Shift (9:00 AM - 6:00 PM)"
```

---

#### MAIN CONTENT (grid grid-cols-3: left=2cols, right=1col)

**LEFT — 4 Read-only Sections:**

**Section 1: Quantity Details** (Package icon, bg-[#EEF2FF])
```
Grid grid-cols-5 gap-4 text-sm:
  Qty In | Qty Out | Wastage Qty | Wastage % | Balance Qty
  Each: label text-xs text-[#64748B] + value text-base font-semibold
```

**Section 2: Job Work Details** (IndianRupee icon, bg-[#F0FDF4])
```
Grid grid-cols-4 gap-4:
  Job Work Type | Rate (Per Pc) | Payment Type | Total Job Work Amount
```

**Section 3: Worker Assignment** (Users icon, bg-[#EEF2FF])
```
Grid grid-cols-4 gap-4:
  Worker / Tailor | Worker Type | No. of Workers | Total Labor Cost
```

**Section 4: Additional Information** (FileText icon, bg-[#FEF9C3])
```
Grid grid-cols-3 gap-4:

Col 1 — Remarks:
  Text-sm text-[#374151] (reads existing remarks)

Col 2 — Custom Fields:
  Each custom field: label + value in read-only format
  Thread Colour: "White"
  Machine Used: "JUKI DDL-8700"

Col 3 — Attachments:
  Each attachment: flex items-center gap-3
    File icon (colored) + filename + filesize
    Download icon button
```

**Section 5: Timeline** (Clock icon, bg-[#EEF2FF])
```
Horizontal timeline (Section 2.8):
  4 steps: Entry Created → In Quantity Recorded → Out Quantity Recorded → Marked as Completed
  Each shows: step label + date + time
  All 4 green in this "Completed" example
```

---

**RIGHT — 3 stacked cards:**

**Lot & Stage Summary:**
```
Title: "Lot & Stage Summary" ClipboardList icon
Rows:
  Lot No.           | LOT-24-05-001
  Design            | Design 1001
  Colour            | ● Red
  Size Set          | S, M, L, XL
  Stage             | 2 - Stitching
  Stage Sequence    | 2 of 4
```

**Quantity Summary (Lot):**
```
Title: "Quantity Summary (Lot)" BarChart2 icon text-[#6366F1]
Rows:
  Total Lot Quantity:            1,200
  Completed Qty (Till Prev. Stage): 1,200
  This Stage - Qty Out:          1,120
  Pending Quantity:              600
```

**Financial Summary (This Entry):**
```
Title: "Financial Summary (This Entry)" IndianRupee icon text-[#15803D]
Rows:
  Rate (Per Pc):        ₹12.00
  Total Job Work Amount: ₹13,440.00
  Labor Cost:           ₹13,440.00
  Payment Status:       "Paid" badge
  Paid Amount:          ₹13,440.00 text-[#15803D]
  Paid On:              26 May 2024
  Balance Payable:      ₹0.00
```

**Note Card:**
```
bg-[#FFFBEB] border border-[#FDE68A] rounded-xl p-4
Lightbulb icon text-[#D97706] + "Note" text-sm font-semibold text-[#D97706]
"This entry is locked. You can edit only if you want to make any corrections (if allowed)."
text-xs text-[#374151]
```

---

### 5.9 Job Work List — `/production/job-work/list`

**Page title:** "Job Work List"
**Breadcrumb:** Production > Job Work > Job Work List
**Header buttons:** "Export" (outline, Upload icon) + "+ Add Stage Entry" (primary)

---

#### FILTER BAR (above stat cards)

```
flex items-center gap-3 flex-wrap

Date Range: w-[200px]
Worker/Tailor: "All Workers" w-[160px]
Stage: "All Stages" w-[160px]
Lot: "All Lots" w-[160px]
Payment Status: "All Status" w-[160px]
Search: "Search by Lot No., Worker..." flex-1
"Clear Filters" text link: RotateCcw icon text-[#6366F1] (right-aligned)
```

---

#### 4 STAT CARDS (grid grid-cols-4 gap-4 mb-4)

```
Card 1: Total Entries
  Icon: ClipboardList, bg-[#EEF2FF], color #6366F1
  Value: "42" text-2xl font-bold
  Sub: "This Period"

Card 2: Total Job Work Amount
  Icon: IndianRupee, bg-[#F0FDF4], color #16A34A
  Value: "₹2,45,780.00" text-xl font-bold
  Sub: "This Period"

Card 3: Total Paid Amount
  Icon: CheckCircle, bg-[#DBEAFE], color #1D4ED8  
  Value: "₹1,85,300.00" text-xl font-bold
  Sub: "This Period"

Card 4: Total Outstanding
  Icon: Clock, bg-[#FEF2F2], color #DC2626
  Value: "₹60,480.00" text-xl font-bold text-[#DC2626]
  Sub: "This Period"
```

---

#### JOB WORK ENTRIES TABLE

```
Title row: flex items-center justify-between mb-3
  "Job Work Entries" text-sm font-semibold
  "Showing 1 to 10 of 42 entries" | "10 per page" dropdown

Sortable column headers (↑↓ arrows): Entry Date, Qty Out, Total Amount

Columns: # | Entry Date | Lot No. | Stage | Worker/Tailor | Qty Out | Job Work Rate (Per Pc) | Total Amount | Payment Status | Outstanding | Actions

# : text-sm text-[#64748B]
Entry Date: text-sm text-[#374151]
Lot No.: text-sm font-mono text-[#6366F1] hover:underline (link to lot detail)
Stage: text-sm text-[#374151]
Worker/Tailor: text-sm text-[#374151]
Qty Out: text-sm text-right text-[#374151]
Job Work Rate: text-sm text-right "₹12.00"
Total Amount: text-sm text-right font-medium text-[#374151]
Payment Status badge:
  Paid:    bg-[#DCFCE7] text-[#15803D]
  Partial: bg-[#FEF3C7] text-[#D97706]
  Unpaid:  bg-[#FEE2E2] text-[#DC2626]
Outstanding: text-sm text-right
  0.00 → text-[#374151]
  >0 → text-[#DC2626] font-medium

Actions: flex items-center gap-2
  Eye: w-8 h-8 border rounded-lg (view stage entry detail)
  ⋮ MoreVertical: dropdown: Record Payment | View Lot

FOOTER: pagination + per-page selector
```

---

### 5.10 Job Worker Ledger — `/production/job-work/ledger/[workerId]`

**Page title:** "Job Worker Ledger"
**Breadcrumb:** Production > Job Work > Job Worker Ledger
**Header buttons:** "Export Ledger" (outline, Download icon) + "Record Payment" (primary, CheckCircle icon)

---

#### WORKER HEADER CARD

```
Full-width card: bg-white rounded-xl border border-[#E5E7EB] p-5 mb-4

Layout: flex items-start gap-6

LEFT — Worker info:
  Initials circle: w-14 h-14 rounded-full bg-[#6366F1] text-white text-xl font-bold — "SS"
  Name: text-xl font-bold text-[#0F172A]
  "Job Worker" badge: bg-[#EDE9FE] text-[#7C3AED]
  Phone: text-sm text-[#374151] (Phone icon)
  Worker code: "JW-0007" text-sm font-mono text-[#64748B]
  Bank: text-sm text-[#64748B] (Building2 icon)
  Address: text-sm text-[#64748B] (MapPin icon)

RIGHT — 3 detail items:
  Worker Type: Job Worker
  Rate (Per Pc): ₹12.00
  Status: Active badge
  Joined: 15 Mar 2024
  Joined (date): blurred/private in screen (text-[#94A3B8])
```

---

#### 4 STAT CARDS (grid grid-cols-4 gap-4 mb-4)

```
Card 1: Total Job Work Amount
  Icon: IndianRupee, bg-[#EEF2FF], color #6366F1
  Value: "₹2,45,780.00" text-xl font-bold
  Sub: "All Time"

Card 2: Total Paid Amount
  Icon: CheckCircle, bg-[#F0FDF4], color #16A34A
  Value: "₹1,85,300.00" text-xl font-bold text-[#15803D]
  Sub: "All Time"

Card 3: Total Outstanding
  Icon: Clock, bg-[#FEF9C3], color #D97706
  Value: "₹60,480.00" text-xl font-bold text-[#D97706]
  Sub: "All Time"

Card 4: Total Entries
  Icon: ClipboardList, bg-[#EEF2FF], color #6366F1
  Value: "28" text-2xl font-bold
  Sub: "All Time"
```

---

#### FILTER BAR + LEDGER TABLE

```
flex items-center gap-3 mb-4
  Date Range | Lot dropdown | Stage dropdown | Payment Status | Search input

LEDGER TABLE:
Columns: # | Date | Entry Type | Ref. No. | Lot No. | Stage | Qty (Out) | Rate (Per Pc) | Amount (₹) | Payment | Balance (₹) | Actions

# : text-sm text-[#64748B]
Date: text-sm text-[#374151]
Entry Type badge:
  Stage Entry: bg-[#DBEAFE] text-[#1D4ED8]
  Payment:     bg-[#DCFCE7] text-[#15803D]
Ref. No.: text-sm font-mono text-[#374151]
Lot No.: text-sm font-mono text-[#6366F1] (link)
Stage: text-sm text-[#374151] (only for Stage Entry rows)
Qty (Out): text-sm text-right text-[#374151] (only for Stage Entry rows)
Rate: text-sm text-right "₹4.00" (only for Stage Entry rows)
Amount: text-sm text-right font-medium text-[#374151]
Payment: text-sm text-right text-[#15803D] font-medium
  Shows "-" for Stage Entry rows
  Shows "₹5,000.00" for Payment rows (green)
Balance: text-sm text-right font-bold text-[#374151]
  Increases after Stage Entry
  Decreases after Payment
Actions: Eye icon button only

FOOTER: pagination + per-page
```

---

#### RIGHT PANEL (grid grid-cols-3: main=2, right=1)

**Outstanding Summary:**
```
Card: bg-white rounded-xl border border-[#E5E7EB] p-5

Title: "Outstanding Summary" ShoppingBag icon text-[#DC2626]

Outstanding Amount (large):
  "₹60,480.00" text-3xl font-bold text-[#DC2626]
  "Outstanding Amount" text-xs text-[#64748B] mt-1

Divider

Rows:
  Total Job Work Amount: ₹2,45,780.00
  Total Paid Amount:     ₹1,85,300.00
  Outstanding Amount:    ₹60,480.00 text-[#DC2626]
```

**Stage Wise Outstanding (don
<truncated 23677 bytes>

NOTE: The output was truncated because it was too long. Use a more targeted query or a smaller range to get the information you need.