const { Client } = require('pg');

const host = 'db.cxekeitxvfkukujselxr.supabase.co';
const port = 5432;
const user = 'postgres';
const password = 'tas_erp';
const database = 'postgres';

async function connectWithRetry(retries = 10, delay = 2000) {
  for (let i = 0; i < retries; i++) {
    const client = new Client({
      host,
      port,
      user,
      password,
      database,
      ssl: { rejectUnauthorized: false }
    });

    try {
      await client.connect();
      return client;
    } catch (err) {
      console.warn(`Connection attempt ${i + 1} failed: ${err.message}`);
      await client.end().catch(() => {});
      if (i < retries - 1) {
        await new Promise(res => setTimeout(res, delay));
      } else {
        throw err;
      }
    }
  }
}

async function run() {
  let client;
  try {
    client = await connectWithRetry();
    console.log("Connected successfully.");

    // Check if we can select from workers
    console.log("Selecting from workers...");
    const res = await client.query("SELECT * FROM workers LIMIT 1;");
    console.log("Selected successfully. Rows:", res.rows);

  } catch (err) {
    console.error("Execution failed:", err.message);
  } finally {
    if (client) {
      await client.end();
    }
  }
}

run();
